
## ADVTRAINS ## realistic trains in Minetest!
by orwell96 and contributors(see below)

For up-to-date information, visit https://forum.minetest.net/viewtopic.php?f=9&t=14726

Manual:
If manual.pdf is not present (which is the case when you downloaded the zip file), see https://github.com/orwell96/advtrains/blob/master/manual.pdf

License of code: LGPL 2.1
License of media: CC-BY-NC-SA 3.0

Contributions:

Gravel Texture              : from Minetest Game
Initial rail model/texture  : DS-minetest
Models for signals/bumpers  : mbb
Steam engine / wagon texture: mbb