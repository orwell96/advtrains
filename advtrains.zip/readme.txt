
## ADVTRAINS ## realistic trains in Minetest!
by orwell96 and contributors(see below)

For up-to-date information, visit https://forum.minetest.net/viewtopic.php?f=9&t=14726

### How to drive trains
(The non-pdf manual file got corrupted, one day I need to make a new manual. Meanwhile here)
First of all: you can always get off the train with right-click.

While on a train:
W - faster
S - slower / change direction 
Space: brake
Shift+S: set speed to 0 (train rolls out, brake to stop!)
Shift+W: Set full speed
Shift+A: Set speed to 4 (~40km/h)
Shift+D: Set speed to 8 (~100km/h)
Shift+Space: toggle brake
Shift+Use: get off



Manual:
If manual.pdf is not present (which is the case when you downloaded the zip file), see https://github.com/orwell96/advtrains/blob/master/manual.pdf

License of code: LGPL 2.1
License of media: CC-BY-NC-SA 3.0

Contributions:

Gravel Texture              : from Minetest Game
Initial rail model/texture  : DS-minetest
Models for signals/bumpers  : mbb
Steam engine / wagon texture: mbb
Industrial engine/wagons    : mbb
Inventory images            : mbb
Small code contributions    : NaruTrey / gpcf