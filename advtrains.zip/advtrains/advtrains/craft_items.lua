 
core.register_craftitem("advtrains:boiler", {
	description = "Boiler",
	inventory_image = "advtrains_boiler.png",
})

 
core.register_craftitem("advtrains:driver_cab", {
	description = "driver's cab",
	inventory_image = "advtrains_driver_cab.png",
})

 
core.register_craftitem("advtrains:wheel", {
	description = "Wheel",
	inventory_image = "advtrains_wheel.png",
})


core.register_craftitem("advtrains:chimney", {
	description = "Chimney",
	inventory_image = "advtrains_chimney.png",
})
