--atc.lua
--registers and controls the ATC system

--(simple)mesecon detector rails
